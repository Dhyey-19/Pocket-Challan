window.AppUtils = (() => {
  const sortByIdAsc = (rows) =>
    [...rows].sort((left, right) => Number(left.id) - Number(right.id));

  const getTodayValue = () => new Date().toISOString().slice(0, 10);

  const formatNumber = (value, digits = 2) => Number(value || 0).toFixed(digits);

  const createEmptyChallanItem = () => ({
    itemId: "",
    grossWeight: "",
    bagsCrate: "",
    lessWeight: "",
    pcs: "",
    unit: "per_kg",
    rate: "",
    notes: ""
  });

  const createEmptyMaterialOutItem = () => ({
    itemId: "",
    grossWeight: "",
    bagsCrate: "",
    lessWeight: "",
    pcs: "",
    processType: ""
  });

  const createEmptyMaterialInItem = () => ({
    itemId: "",
    materialOutItemId: "",
    grossWeight: "",
    bagsCrate: "",
    lessWeight: "",
    pcs: "",
    unit: "per_kg",
    rate: "",
    processType: "",
    weightBalance: "",
    pcsBalance: ""
  });

  const getNetWeight = (item) => {
    const gross = Number(item.grossWeight || 0);
    const less = Number(item.lessWeight || 0);
    return gross - less;
  };

  const getAmount = (item) => {
    const rate = Number(item.rate || 0);
    const netWeight = getNetWeight(item);
    if (item.unit === "per_pcs") {
      return Number(item.pcs || 0) * rate;
    }
    return netWeight * rate;
  };

  const buildChallanPrintHtml = (challan, items) => {
    const totals = items.reduce(
      (acc, item) => {
        acc.grossWeight += Number(item.grossWeight || 0);
        acc.bagsCrate += Number(item.bagsCrate || 0);
        acc.lessWeight += Number(item.lessWeight || 0);
        acc.netWeight += Number(item.netWeight || 0);
        acc.pcs += Number(item.pcs || 0);
        acc.amount += Number(item.amount || 0);
        return acc;
      },
      { grossWeight: 0, bagsCrate: 0, lessWeight: 0, netWeight: 0, pcs: 0, amount: 0 }
    );

    const rowsHtml = items
      .map(
        (item) => `
          <tr>
            <td>${item.itemName || ""}</td>
            <td class="num">${formatNumber(item.grossWeight, 3)}</td>
            <td class="num">${formatNumber(item.bagsCrate, 0)}</td>
            <td class="num">${formatNumber(item.lessWeight, 3)}</td>
            <td class="num">${formatNumber(item.netWeight, 3)}</td>
            <td class="num">${formatNumber(item.pcs, 0)}</td>
            <td>${item.unit === "per_pcs" ? "per PCS" : "per KG"}</td>
            <td class="num">${formatNumber(item.rate, 2)}</td>
            <td class="num">${formatNumber(item.amount, 2)}</td>
            <td>${item.notes || ""}</td>
          </tr>
        `
      )
      .join("");

    return `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <title>Delivery Challan</title>
          <style>
            * { box-sizing: border-box; }
            body { font-family: "Times New Roman", serif; margin: 24px; color: #000; }
            .title { text-align: center; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
            .header-grid { border: 1px solid #000; border-bottom: none; padding: 10px; }
            .header-row { display: flex; justify-content: space-between; gap: 16px; }
            .header-row + .header-row { margin-top: 6px; }
            .label { font-weight: bold; }
            .value { font-weight: bold; }
            table { width: 100%; border-collapse: collapse; font-size: 14px; }
            th, td { border: 1px solid #000; padding: 6px; text-align: left; }
            th { text-align: center; font-weight: bold; }
            .num { text-align: right; }
            .totals td { font-weight: bold; }
            .footer-table { width: 100%; border-collapse: collapse; border: 1px solid #000; border-top: none; }
            .footer-table td { border-right: 1px solid #000; padding: 8px 10px; vertical-align: top; height: 48px; }
            .footer-table td:last-child { border-right: none; text-align: right; }
            .sign { font-weight: bold; text-align: right; }
          </style>
        </head>
        <body>
          <div class="title">Delivery Challan</div>
          <div class="header-grid">
            <div class="header-row">
              <div class="label">PARTY NAME :</div>
              <div class="label">CHALLAN NO : ${challan.challanNo}</div>
            </div>
            <div class="header-row">
              <div class="value">${challan.partyName || ""}</div>
              <div class="label">CHALLAN DATE : ${challan.challanDate}</div>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Description</th>
                <th>Gross Weight</th>
                <th>No. of Bags/Crate</th>
                <th>Less</th>
                <th>Net Weight</th>
                <th>PCS</th>
                <th>per Kg/Pcs</th>
                <th>Rate</th>
                <th>Amount</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
              <tr class="totals">
                <td>Total</td>
                <td class="num">${formatNumber(totals.grossWeight, 3)}</td>
                <td class="num">${formatNumber(totals.bagsCrate, 0)}</td>
                <td class="num">${formatNumber(totals.lessWeight, 3)}</td>
                <td class="num">${formatNumber(totals.netWeight, 3)}</td>
                <td class="num">${formatNumber(totals.pcs, 0)}</td>
                <td></td>
                <td></td>
                <td class="num">${formatNumber(totals.amount, 2)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
          <table class="footer-table">
            <tr>
              <td>
                <div class="label">Remarks</div>
                <div>${challan.remarks || ""}</div>
              </td>
              <td>
                <div class="label">Vehicle</div>
                <div>${challan.vehicleNo || ""}</div>
              </td>
              <td></td>
            </tr>
            <tr>
              <td>
                <div class="label">Bill No.</div>
                <div>${challan.billNo || ""}</div>
              </td>
              <td></td>
              <td class="sign">Sign</td>
            </tr>
          </table>
          <script>
            window.print();
          </script>
        </body>
      </html>
    `;
  };

  const buildMaterialOutPrintHtml = (challan, items) => {
    const totals = items.reduce(
      (acc, item) => {
        acc.grossWeight += Number(item.grossWeight || 0);
        acc.bagsCrate += Number(item.bagsCrate || 0);
        acc.lessWeight += Number(item.lessWeight || 0);
        acc.netWeight += Number(item.netWeight || 0);
        acc.pcs += Number(item.pcs || 0);
        return acc;
      },
      { grossWeight: 0, bagsCrate: 0, lessWeight: 0, netWeight: 0, pcs: 0 }
    );

    const rowsHtml = items
      .map(
        (item) => `
          <tr>
            <td>${item.itemName || ""}</td>
            <td class="num">${formatNumber(item.grossWeight, 3)}</td>
            <td class="num">${formatNumber(item.bagsCrate, 0)}</td>
            <td class="num">${formatNumber(item.lessWeight, 3)}</td>
            <td class="num">${formatNumber(item.netWeight, 3)}</td>
            <td class="num">${formatNumber(item.pcs, 0)}</td>
            <td>${item.processType || ""}</td>
          </tr>
        `
      )
      .join("");

    return `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <title>Material Out</title>
          <style>
            * { box-sizing: border-box; }
            body { font-family: "Times New Roman", serif; margin: 24px; color: #000; }
            .title { text-align: center; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
            .header-grid { border: 1px solid #000; border-bottom: none; padding: 10px; }
            .header-row { display: flex; justify-content: space-between; gap: 16px; }
            .header-row + .header-row { margin-top: 6px; }
            .label { font-weight: bold; }
            .value { font-weight: bold; }
            table { width: 100%; border-collapse: collapse; font-size: 14px; }
            th, td { border: 1px solid #000; padding: 6px; text-align: left; }
            th { text-align: center; font-weight: bold; }
            .num { text-align: right; }
            .totals td { font-weight: bold; }
            .footer-table { width: 100%; border-collapse: collapse; border: 1px solid #000; border-top: none; }
            .footer-table td { border-right: 1px solid #000; padding: 8px 10px; vertical-align: top; height: 48px; }
            .footer-table td:last-child { border-right: none; text-align: right; }
            .sign { font-weight: bold; text-align: right; }
          </style>
        </head>
        <body>
          <div class="title">Material Out</div>
          <div class="header-grid">
            <div class="header-row">
              <div class="label">Party Name:- ${challan.partyName || ""}</div>
              <div class="label">Challan No:- ${challan.challanNo}</div>
            </div>
            <div class="header-row">
              <div></div>
              <div class="label">Challan Date:- ${challan.challanDate}</div>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Description</th>
                <th>Gross Weight</th>
                <th>No. of Bags Crate</th>
                <th>Less</th>
                <th>Net Weight</th>
                <th>PCS</th>
                <th>Type of Process</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
              <tr class="totals">
                <td>Total</td>
                <td class="num">${formatNumber(totals.grossWeight, 3)}</td>
                <td class="num">${formatNumber(totals.bagsCrate, 0)}</td>
                <td class="num">${formatNumber(totals.lessWeight, 3)}</td>
                <td class="num">${formatNumber(totals.netWeight, 3)}</td>
                <td class="num">${formatNumber(totals.pcs, 0)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
          <table class="footer-table">
            <tr>
              <td>
                <div class="label">Remarks</div>
                <div>${challan.remarks || ""}</div>
              </td>
              <td>
                <div class="label">Vehicle</div>
                <div>${challan.vehicleNo || ""}</div>
              </td>
              <td class="sign">Sign</td>
            </tr>
          </table>
          <script>
            window.print();
          </script>
        </body>
      </html>
    `;
  };

  const buildMaterialInPrintHtml = (challan, items) => {
    const totals = items.reduce(
      (acc, item) => {
        acc.grossWeight += Number(item.grossWeight || 0);
        acc.bagsCrate += Number(item.bagsCrate || 0);
        acc.lessWeight += Number(item.lessWeight || 0);
        acc.netWeight += Number(item.netWeight || 0);
        acc.pcs += Number(item.pcs || 0);
        acc.amount += Number(item.amount || 0);
        return acc;
      },
      { grossWeight: 0, bagsCrate: 0, lessWeight: 0, netWeight: 0, pcs: 0, amount: 0 }
    );

    const rowsHtml = items
      .map(
        (item) => `
          <tr>
            <td>${item.itemName || ""}</td>
            <td class="num">${formatNumber(item.grossWeight, 3)}</td>
            <td class="num">${formatNumber(item.bagsCrate, 0)}</td>
            <td class="num">${formatNumber(item.lessWeight, 3)}</td>
            <td class="num">${formatNumber(item.netWeight, 3)}</td>
            <td class="num">${formatNumber(item.pcs, 0)}</td>
            <td>${item.unit === "per_pcs" ? "per PCS" : "per KG"}</td>
            <td class="num">${formatNumber(item.rate, 2)}</td>
            <td class="num">${formatNumber(item.amount, 2)}</td>
            <td>${item.processType || ""}</td>
          </tr>
        `
      )
      .join("");

    return `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <title>Material In</title>
          <style>
            * { box-sizing: border-box; }
            body { font-family: "Times New Roman", serif; margin: 24px; color: #000; }
            .title { text-align: center; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
            .header-grid { border: 1px solid #000; border-bottom: none; padding: 10px; }
            .header-row { display: flex; justify-content: space-between; gap: 16px; }
            .header-row + .header-row { margin-top: 6px; }
            .label { font-weight: bold; }
            .value { font-weight: bold; }
            table { width: 100%; border-collapse: collapse; font-size: 14px; }
            th, td { border: 1px solid #000; padding: 6px; text-align: left; }
            th { text-align: center; font-weight: bold; }
            .num { text-align: right; }
            .totals td { font-weight: bold; }
            .footer-table { width: 100%; border-collapse: collapse; border: 1px solid #000; border-top: none; }
            .footer-table td { border-right: 1px solid #000; padding: 8px 10px; vertical-align: top; height: 48px; }
            .footer-table td:last-child { border-right: none; text-align: right; }
            .sign { font-weight: bold; text-align: right; }
          </style>
        </head>
        <body>
          <div class="title">Material In</div>
          <div class="header-grid">
            <div class="header-row">
              <div class="label">Party Name:- ${challan.partyName || ""}</div>
              <div class="label">Challan No:- ${challan.challanNo}</div>
            </div>
            <div class="header-row">
              <div></div>
              <div class="label">Challan Date:- ${challan.challanDate}</div>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Description</th>
                <th>Gross Weight</th>
                <th>No. of Bags Crate</th>
                <th>Less</th>
                <th>Net Weight</th>
                <th>PCS</th>
                <th>per Kg/Pcs</th>
                <th>Rate</th>
                <th>Amount</th>
                <th>Type of Process</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
              <tr class="totals">
                <td>Total</td>
                <td class="num">${formatNumber(totals.grossWeight, 3)}</td>
                <td class="num">${formatNumber(totals.bagsCrate, 0)}</td>
                <td class="num">${formatNumber(totals.lessWeight, 3)}</td>
                <td class="num">${formatNumber(totals.netWeight, 3)}</td>
                <td class="num">${formatNumber(totals.pcs, 0)}</td>
                <td></td>
                <td></td>
                <td class="num">${formatNumber(totals.amount, 2)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
          <table class="footer-table">
            <tr>
              <td>
                <div class="label">Remarks</div>
                <div>${challan.remarks || ""}</div>
              </td>
              <td>
                <div class="label">Vehicle</div>
                <div>${challan.vehicleNo || ""}</div>
              </td>
              <td class="sign">Sign</td>
            </tr>
          </table>
          <script>
            window.print();
          </script>
        </body>
      </html>
    `;
  };

  return {
    sortByIdAsc,
    getTodayValue,
    formatNumber,
    createEmptyChallanItem,
    createEmptyMaterialOutItem,
    createEmptyMaterialInItem,
    getNetWeight,
    getAmount,
    buildChallanPrintHtml,
    buildMaterialOutPrintHtml,
    buildMaterialInPrintHtml
  };
})();
